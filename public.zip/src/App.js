
import React from 'react';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { Routes, Route } from 'react-router-dom';
import Home from './Page/Home';
import Edit from './Page/EditPage';
import Event from './Page/Tab/Event';
import Header from './Page/Header';



const App = () => (
  <DndProvider backend={HTML5Backend}>
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/edit" element={<Edit />} />
      <Route path="/event" element={<Event />} />      
      <Route path="/header" element={<Header />} />
    </Routes>
  </DndProvider>
);

export default App;

