// import { CiMobile1 } from "react-icons/ci";
// import { FaDesktop } from "react-icons/fa";

// Drag and drop functinolity for mobile version
// import React, { useState } from 'react';
// import { useDrag } from 'react-dnd';
// import { GoPencil } from 'react-icons/go';
// import { RiPaintFill } from 'react-icons/ri';
// import { MdOutlineVerticalAlignCenter } from 'react-icons/md';
// import { RiDeleteBin6Line } from 'react-icons/ri';
// import { GiPin } from "react-icons/gi";
// import { PiCopySimpleLight } from "react-icons/pi";

// const ItemTypes = {
//   TEXT_ELEMENT: 'TEXT_ELEMENT'
// };

// const TextElement = ({ element, moveTextElement }) => {
//   const [hovered, setHovered] = useState(false);

//   const [{ isDragging }, drag, preview] = useDrag({
//     type: ItemTypes.TEXT_ELEMENT,
//     item: { id: element.id, left: element.left, top: element.top },
//     collect: (monitor) => ({
//       isDragging: monitor.isDragging(),
//     }),
//   });

//   const handleMouseEnter = () => {
//     setHovered(true);
//   };

//   const handleMouseLeave = () => {
//     setHovered(false);
//   };

//   const handleDragEnd = (e) => {
//     const { clientX, clientY } = e;
//     moveTextElement(element.id, clientX, clientY);
//   };

//   const handleTouchStart = (e) => {
//     const touch = e.touches[0];
//     moveTextElement(element.id, touch.clientX, touch.clientY);
//   };

//   const handleTouchMove = (e) => {
//     const touch = e.touches[0];
//     moveTextElement(element.id, touch.clientX, touch.clientY);
//   };

//   const handleTouchEnd = () => {
//     setHovered(false);
//   };

//   return (
//     <div
//       ref={drag}
//       style={{
//         position: 'absolute',
//         left: element.left,
//         top: element.top,
//         transform: 'translate(-50%, -50%)',
//         cursor: isDragging ? 'grabbing' : 'move',
//         fontSize: element.fontSize || '16px',
//         margin: '10px',
//         border: hovered ? '2px dashed white' : 'none',
//         padding: element.type === 'button' ? '10px 20px' : '0',
//         backgroundColor: element.type === 'button' ? 'blue' : 'transparent',
//         color: element.type === 'button' ? 'white' : 'inherit',
//         borderRadius: element.type === 'button' ? '5px' : '0',
//         zIndex: hovered ? 10 : 1,
//         opacity: isDragging ? 0.5 : 1,
//       }}
//       onMouseEnter={handleMouseEnter}
//       onMouseLeave={handleMouseLeave}
//       onDragEnd={handleDragEnd}
//       onTouchStart={handleTouchStart}
//       onTouchMove={handleTouchMove}
//       onTouchEnd={handleTouchEnd}
//       draggable
//     >
//       {element.text}

//       {hovered && (
//         <div className="absolute top-[-42px] flex space-x-2 bg-white text-black p-2 rounded shadow-md">
//           <GoPencil
//             className="cursor-pointer hover:text-yellow-500"
//             title="Edit"
//             style={{ width: '20px', height: '20px', marginRight: '10px' }}
//           />
//           <RiPaintFill
//             className="cursor-pointer hover:text-yellow-500"
//             title="Paint"
//             style={{ width: '20px', height: '20px', marginRight: '10px' }}
//           />
//           <MdOutlineVerticalAlignCenter
//             className="cursor-pointer hover:text-yellow-500"
//             title="Pin"
//             style={{ width: '20px', height: '20px', marginRight: '10px' }}
//           />
//           <GiPin
//             className="cursor-pointer hover:text-yellow-500"
//             title="Split"
//             style={{ width: '20px', height: '20px', marginRight: '10px' }}
//           />
//           <PiCopySimpleLight
//             className="cursor-pointer hover:text-yellow-500"
//             title="Split"
//             style={{ width: '20px', height: '20px', marginRight: '10px' }}
//           />
//           <RiDeleteBin6Line
//             className="cursor-pointer text-red-500 hover:text-red-700"
//             title="Delete"
//             style={{ width: '20px', height: '20px', marginRight: '10px' }}
//           />
//         </div>
//       )}
//     </div>
//   );
// };

// export default TextElement;





























// Drag and drop functinolity
// import React, { useState } from 'react';
// import { useDrag } from 'react-dnd';
// import { GoPencil } from 'react-icons/go';
// import { RiPaintFill } from 'react-icons/ri';
// import { MdOutlineVerticalAlignCenter } from 'react-icons/md';
// import { PiCopySimpleThin } from 'react-icons/pi';
// import { RiDeleteBin6Line } from 'react-icons/ri';

// const ItemTypes = {
//   TEXT_ELEMENT: 'TEXT_ELEMENT'
// };

// const TextElement = ({ element, moveTextElement }) => {
//   const [hovered, setHovered] = useState(false);

//   const [{ isDragging }, drag] = useDrag({
//     type: ItemTypes.TEXT_ELEMENT,
//     item: { id: element.id, left: element.left, top: element.top },
//     collect: (monitor) => ({
//       isDragging: monitor.isDragging(),
//     }),
//   });

//   const handleMouseEnter = () => {
//     setHovered(true);
//   };

//   const handleMouseLeave = () => {
//     setHovered(false);
//   };

//   const handleDragEnd = (e) => {
//     moveTextElement(element.id, e.clientX, e.clientY);
//   };

//   return (
//     <div
//       ref={drag}
//       style={{
//         position: 'absolute',
//         left: element.left,
//         top: element.top,
//         transform: 'translate(-50%, -50%)',
//         cursor: isDragging ? 'grabbing' : 'move',
//         fontSize: element.fontSize || '16px',
//         margin: '10px',
//         border: hovered ? '2px dashed white' : 'none',
//         padding: element.type === 'button' ? '10px 20px' : '0',
//         backgroundColor: element.type === 'button' ? 'blue' : 'transparent',
//         color: element.type === 'button' ? 'white' : 'inherit',
//         borderRadius: element.type === 'button' ? '5px' : '0',
//         zIndex: hovered ? 10 : 1,
//         opacity: isDragging ? 0.5 : 1,
//       }}
//       onMouseEnter={handleMouseEnter}
//       onMouseLeave={handleMouseLeave}
//       onDragEnd={handleDragEnd}
//       draggable
//     >
//       {element.text}
      
      
//       {hovered && (
//                 <div
//                     className="absolute top-[-32px] flex space-x-2 bg-white text-black p-1 rounded shadow-md"
//                 >
//                     <GoPencil
//                         className="cursor-pointer hover:text-yellow-500"
//                         title="Edit"
//                         style={{ width: '20px', height: '20px', marginRight: '6px' }}
//                     />

//                     <RiPaintFill
//                         className="cursor-pointer hover:text-yellow-500"
//                         title="Paint"
//                         style={{ width: '20px', height: '20px', marginLeft: '10px' }}
//                     />

//                     <MdOutlineVerticalAlignCenter
//                         className="cursor-pointer hover:text-yellow-500"
//                         title="Pin"
//                         style={{ width: '20px', height: '20px', marginLeft: '10px' }}
//                     />

//                     {/* <MdOutlinePushPin
//                         className="cursor-pointer hover:text-yellow-500"
//                         title="Copy"
//                         style={{ width: '20px', height: '20px', marginLeft: '10px' }}
//                     /> */}

//                     <MdOutlineVerticalAlignCenter
//                         className="cursor-pointer hover:text-yellow-500"
//                         title="Split"
//                         style={{ width: '20px', height: '20px', marginLeft: '10px' }}
//                     />

//                     <RiDeleteBin6Line
//                         className="cursor-pointer text-red-500 hover:text-red-700"
//                         title="Delete"
//                         style={{ width: '20px', height: '20px', marginLeft: '10px' }}
//                     />
//                 </div>
//             )}
//     </div>
//   );
// };

// export default TextElement;














// import React, { useState } from 'react';
// import { useDrag } from 'react-dnd';
// import { GoPencil } from 'react-icons/go';
// import { RiPaintFill } from 'react-icons/ri';
// import { MdOutlinePushPin, MdOutlineVerticalAlignCenter } from 'react-icons/md';
// import { PiCopySimpleThin } from 'react-icons/pi';
// import { FaAngleDown } from "react-icons/fa6";
// import { RiDeleteBin6Line } from 'react-icons/ri';

// const TextElement = ({ element, moveTextElement }) => {
//     const [hovered, setHovered] = useState(false);

//     const [dropdownOpen, setDropdownOpen] = useState(false);

//     const handleMouseEnter = () => {
//         setHovered(true);
//     };

//     const toggleDropdown = () => {
//         setDropdownOpen(!dropdownOpen);
//     };


//     const [, drag] = useDrag({
//         type: 'TEXT_ELEMENT',
//         item: { id: element.id },
//     });

//     const style = {
//         position: 'absolute',
//         left: element.left,
//         top: element.top,
//         transform: 'translate(-50%, -50%)',
//         cursor: 'move',
//         fontSize: element.fontSize || '16px',
//         margin: '10px',
//         border: hovered ? '2px dashed white' : 'none',
//         padding: element.type === 'button' ? '10px 20px' : '0',
//         backgroundColor: element.type === 'button' ? 'blue' : 'transparent',
//         color: element.type === 'button' ? 'white' : 'inherit',
//         borderRadius: element.type === 'button' ? '5px' : '0',
//     };

//     const handleMouseLeave = () => {
//         setHovered(false);
//     };

//     return (
//         <div
//             ref={drag}
//             style={style}
//             onMouseEnter={handleMouseEnter}
//             onMouseLeave={handleMouseLeave}
//         >
//             {element.text}

//             {hovered && (
//                 <div className="relative" style={{ margin: '0 20px' }}>
//                     {/* Icon Tab */}
//                     <div
//                         className="absolute top-[-75px] flex space-x-2 bg-white text-black p-1 rounded shadow-md"
                        
//                     >
//                         <GoPencil
//                             className="cursor-pointer hover:text-yellow-500"
//                             title="Edit"
//                             style={{ width: '20px', height: '20px', margin: '7 5px', marginRight:'6px' }} // Fixed size & margin
//                         />
//                         <div className="relative flex items-center">
//                             <button
//                                 className="flex items-center cursor-pointer hover:text-yellow-500"
//                                 onClick={toggleDropdown}
//                                 style={{ width: '60px', marginRight: '5px', marginRight:'9px' }} // Fixed size & margin
//                             >
//                                 Primary
//                                     <FaAngleDown />        
//                             </button>
//                             {dropdownOpen && (
//                                 <ul className="absolute top-full left-0 mt-2 bg-white text-black rounded shadow-lg w-40">
//                                     <li className="p-2 hover:bg-gray-200 cursor-pointer">Option 1</li>
//                                     <li className="p-2 hover:bg-gray-200 cursor-pointer">Option 2</li>
//                                 </ul>
//                             )}
//                         </div>
//                         <RiPaintFill
//                             className="cursor-pointer hover:text-yellow-500"
//                             title="Paint"
//                             style={{ width: '20px', height: '20px', margin: '6 5px', marginLeft:'10px' }} // Fixed size & margin
//                         />
                        
//                         <MdOutlinePushPin
//                             className="cursor-pointer hover:text-yellow-500"
//                             title="Pin"
//                             style={{ width: '20px', height: '20px', margin: '7 5px', marginLeft:'10px' }} // Fixed size & margin
//                         />
//                         <PiCopySimpleThin
//                             className="cursor-pointer hover:text-yellow-500"
//                             title="Copy"
//                             style={{ width: '20px', height: '20px', margin: '7 5px', marginLeft:'10px' }} // Fixed size & margin
//                         />
//                         <MdOutlineVerticalAlignCenter
//                             className="cursor-pointer hover:text-yellow-500"
//                             title="Split"
//                             style={{ width: '20px', height: '20px', margin: '7 5px', marginLeft:'10px' }} // Fixed size & margin
//                         />
//                         <RiDeleteBin6Line
//                             className="cursor-pointer text-red-500 hover:text-red-700"
//                             title="Delete"
//                             style={{ width: '20px', height: '20px', margin: '7 5px', marginLeft:'10px' }} // Fixed size & margin
//                         />
//                     </div>
//                 </div>
//             )}
//         </div>
//     );
// };

// export default TextElement;









// import React, { useState } from 'react';
// import { FaBars, FaTimes } from 'react-icons/fa';
// import { Link } from 'react-router-dom';
// import { useDrop } from 'react-dnd';
// import BackgroundImage from "../Assets/restaurant-wallpaper.jpg";
// import { IoReturnUpForward, IoReturnUpBack } from "react-icons/io5";
// import TextElement from './DragItem'; // Updated import

// const Edit = () => {
//     const [isOpen, setIsOpen] = useState(false);
//     const [textElements, setTextElements] = useState([
//         { id: 1, text: 'Welcome to Our Restaurant', left: '25%', top: '50%' },
//         { id: 2, text: 'Book your table today!', left: '50%', top: '15%' },
//         { id: 3, text: 'Special Offers', left: '75%', top: '25%' },
//     ]);

//     const moveTextElement = (id, left, top) => {
//         setTextElements((prevElements) =>
//             prevElements.map((element) =>
//                 element.id === id ? { ...element, left, top } : element
//             )
//         );
//     };

//     const [, drop] = useDrop({
//         accept: 'TEXT_ELEMENT',
//         drop: (item, monitor) => {
//             const offset = monitor.getClientOffset();
//             const rect = document.getElementById('canvas').getBoundingClientRect();
//             const x = offset.x - rect.left;
//             const y = offset.y - rect.top;
//             moveTextElement(item.id, `${x}px`, `${y}px`);
//         },
//     });

//     const toggleMenu = () => {
//         setIsOpen(!isOpen);
//     };

//     return (
//         <div className="relative w-full h-screen" ref={drop} id="canvas">
//             <img
//                 src={BackgroundImage}
//                 alt="Background"
//                 className="absolute inset-0 w-full h-full object-cover"
//             />

//             <nav className="absolute top-0 left-0 w-full flex items-center justify-between p-4 bg-opacity-50 bg-black text-white z-20">
//                 <div className="flex items-center">
//                     <Link to="/Edit" className="p-4 text-lg font-semibold">Save</Link>
//                     <Link to="/Edit" className="p-4 text-lg font-semibold">Exit</Link>
//                     <IoReturnUpBack style={{ width: '24px', height: '24px' }} />
//                     <IoReturnUpForward style={{ width: '24px', height: '24px' }} />
//                 </div>
//                 <div className="lg:hidden" onClick={toggleMenu}>
//                     {isOpen ? <FaTimes /> : <FaBars />}
//                 </div>
//                 <ul className={`lg:flex lg:items-center lg:space-x-6 absolute item-end lg:static top-16 left-0 w-full lg:w-auto bg-black lg:bg-transparent transition-transform duration-300 ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}>
//                     <li className="p-4"><a href="/">Home</a></li>
//                     <li className="p-4"><a href="/Edit">About</a></li>
//                 </ul>
//             </nav>

//             <div className="absolute inset-0 flex flex-col items-center justify-center text-center text-white z-10">
//                 {textElements.map((element) => (
//                     <TextElement
//                         key={element.id}
//                         element={element}
//                         moveTextElement={moveTextElement}
//                     />
//                 ))}
//             </div>
//         </div>
//     );
// };

// export default Edit;



















// import React, { useState } from 'react';
// import { useDrag } from 'react-dnd';
// import { GoPencil } from 'react-icons/go';
// import { RiPaintFill, RiDeleteBin6Line } from 'react-icons/ri';
// import { MdOutlinePushPin, MdOutlineVerticalAlignCenter } from 'react-icons/md';

// const TextElement = ({ element, moveTextElement }) => {
//     const [hovered, setHovered] = useState(false);
//     const [dropdownOpen, setDropdownOpen] = useState(false);

//     const toggleDropdown = () => {
//         setDropdownOpen(!dropdownOpen);
//     };

//     const [, drag] = useDrag({
//         type: 'TEXT_ELEMENT',
//         item: { id: element.id },
//     });

//     const style = {
//         position: 'absolute',
//         left: element.left,
//         top: element.top,
//         transform: 'translate(-50%, -50%)',
//         cursor: 'move',
//         fontSize: element.fontSize || '16px',
//         margin: '10px',
//         border: hovered ? '2px dashed white' : 'none',
//         padding: element.type === 'button' ? '10px 20px' : '0',
//         backgroundColor: element.type === 'button' ? 'blue' : 'transparent',
//         color: element.type === 'button' ? 'white' : 'inherit',
//         borderRadius: element.type === 'button' ? '5px' : '0',
//     };

//     const handleMouseEnter = () => {
//         setHovered(true);
//     };

//     const handleMouseLeave = () => {
//         setHovered(false);
//     };

//     return (
//         <div
//             ref={drag}
//             style={style}
//             onMouseEnter={handleMouseEnter}
//             onMouseLeave={handleMouseLeave}
//         >
//             {element.text}

//             {hovered && (
//                 <div
//                     className="absolute top-[-32px] flex space-x-2 bg-white text-black p-1 rounded shadow-md"
//                 >
//                     <GoPencil
//                         className="cursor-pointer hover:text-yellow-500"
//                         title="Edit"
//                         style={{ width: '20px', height: '20px', marginRight: '6px' }}
//                     />

//                     <RiPaintFill
//                         className="cursor-pointer hover:text-yellow-500"
//                         title="Paint"
//                         style={{ width: '20px', height: '20px', marginLeft: '10px' }}
//                     />

//                     <MdOutlineVerticalAlignCenter
//                         className="cursor-pointer hover:text-yellow-500"
//                         title="Pin"
//                         style={{ width: '20px', height: '20px', marginLeft: '10px' }}
//                     />

//                     <MdOutlinePushPin
//                         className="cursor-pointer hover:text-yellow-500"
//                         title="Copy"
//                         style={{ width: '20px', height: '20px', marginLeft: '10px' }}
//                     />

//                     <MdOutlineVerticalAlignCenter
//                         className="cursor-pointer hover:text-yellow-500"
//                         title="Split"
//                         style={{ width: '20px', height: '20px', marginLeft: '10px' }}
//                     />

//                     <RiDeleteBin6Line
//                         className="cursor-pointer text-red-500 hover:text-red-700"
//                         title="Delete"
//                         style={{ width: '20px', height: '20px', marginLeft: '10px' }}
//                     />
//                 </div>
//             )}
//         </div>
//     );
// };

// export default TextElement;






// import React, { useState } from 'react';
// import { GoPencil } from 'react-icons/go';
// import { RiPaintFill } from 'react-icons/ri';
// import { MdOutlinePushPin, MdOutlineVerticalAlignCenter } from 'react-icons/md';
// import { PiCopySimpleThin } from 'react-icons/pi';
// import { RiDeleteBin6Line } from 'react-icons/ri';
// import { FaCaretDown } from 'react-icons/fa';
// import { IoLinkSharp } from "react-icons/io5";


// const TextElement = ({ element }) => {
//     const [hovered, setHovered] = useState(false);
//     const [dropdownOpen, setDropdownOpen] = useState(false);

//     const handleMouseEnter = () => {
//         setHovered(true);
//     };

//     const handleMouseLeave = () => {
//         setHovered(false);
//     };

//     const toggleDropdown = () => {
//         setDropdownOpen(!dropdownOpen);
//     };

//     return (
//         <div
//             style={{
//                 position: 'absolute',
//                 left: element.left,
//                 top: element.top,
//                 transform: 'translate(-50%, -50%)',
//                 cursor: 'move',
//                 fontSize: element.fontSize || '16px',
//                 margin: '10px',
//                 border: hovered ? '2px dashed white' : 'none',
//                 padding: element.type === 'button' ? '10px 20px' : '0',
//                 backgroundColor: element.type === 'button' ? 'blue' : 'transparent',
//                 color: element.type === 'button' ? 'white' : 'inherit',
//                 borderRadius: element.type === 'button' ? '5px' : '0',
//                 zIndex: hovered ? 10 : 1,
//             }}
//             onMouseEnter={handleMouseEnter}
//             onMouseLeave={handleMouseLeave}
//         >
//             {element.text}

//             {hovered && (
//                 <div className="relative">
//                     {/* Border Line */}
//                     <div className="absolute inset-0 border-2 border-dashed border-white pointer-events-none" />

//                     {/* Icon Tab for Text Elements */}
//                     {element.type === 'text' && (
//                         <div className="absolute top-[-60px] left-0 flex space-x-2 bg-white text-black p-1 rounded shadow-md">
//                             <GoPencil className="cursor-pointer hover:text-yellow-500" title="Edit" />
//                             <RiPaintFill className="cursor-pointer hover:text-yellow-500" title="Paint" />
//                             <MdOutlineVerticalAlignCenter className="cursor-pointer hover:text-yellow-500" title="Split" />    
//                             <PiCopySimpleThin className="cursor-pointer hover:text-yellow-500" title="Copy" />
//                             <MdOutlinePushPin className="cursor-pointer hover:text-yellow-500" title="Pin" />                       
//                             <RiDeleteBin6Line className="cursor-pointer text-red-500 hover:text-red-700" title="Delete" />
//                         </div>
//                     )}

//                     {/* Icon Tab for Button Elements */}
//                     {element.type === 'button' && (
//                         <div className="absolute top-[-60px] left-0 flex space-x-2 bg-white text-black p-1 rounded shadow-md">
//                              <GoPencil className="cursor-pointer hover:text-yellow-500" title="Edit" />
//                             <RiPaintFill className="cursor-pointer hover:text-yellow-500" title="Paint" />
//                             <MdOutlineVerticalAlignCenter className="cursor-pointer hover:text-yellow-500" title="Split" />    
//                             <MdOutlinePushPin className="cursor-pointer hover:text-yellow-500" title="Pin" />                       
//                             <PiCopySimpleThin className="cursor-pointer hover:text-yellow-500" title="Copy" />                            
//                             <RiDeleteBin6Line className="cursor-pointer text-red-500 hover:text-red-700" title="Delete" />
                        
//                         {/* <GoPencil className="cursor-pointer hover:text-yellow-500" title="Edit" />
//                         <div className="relative">
//                             <button
//                                 className="flex items-center cursor-pointer hover:text-yellow-500"
//                                 onClick={toggleDropdown}
//                             >
//                                 Primary
//                                 <FaCaretDown className="ml-1" />
//                             </button>
//                             {dropdownOpen && (
//                                 <ul className="absolute top-full left-0 mt-2 bg-white text-black rounded shadow-lg w-40">
//                                     <li className="p-2 hover:bg-gray-200 cursor-pointer">Option 1</li>
//                                     <li className="p-2 hover:bg-gray-200 cursor-pointer">Option 2</li>
//                                 </ul>
//                             )}
//                          </div>
//                         <IoLinkSharp  className="cursor-pointer hover:text-yellow-500" title="Link" />
//                         <MdOutlinePushPin className="cursor-pointer hover:text-yellow-500" title="Pin" />
//                         <PiCopySimpleThin className="cursor-pointer hover:text-yellow-500" title="Copy" />
//                         <RiDeleteBin6Line className="cursor-pointer text-red-500 hover:text-red-700" title="Delete" /> */}
//                     </div>
//                     )}
//                 </div>
//             )}
//         </div>
//     );
// };

// export default TextElement;



// import React, { useState } from 'react';
// import { useDrag } from 'react-dnd';
// import { FaPen, FaCopy, FaThumbtack, FaLink, FaTrash } from 'react-icons/fa';

// const TextElement = ({ element, moveTextElement }) => {
//     const [hovered, setHovered] = useState(false);

//     const [, drag] = useDrag({
//         type: 'TEXT_ELEMENT',
//         item: { id: element.id },
//     });

//     const style = {
//         position: 'absolute',
//         left: element.left,
//         top: element.top,
//         transform: 'translate(-50%, -50%)',
//         cursor: 'move',
//         fontSize: element.fontSize || '16px',
//         margin: '10px',
//         border: hovered ? '2px dashed white' : 'none',
//         padding: element.type === 'button' ? '10px 20px' : '0',
//         backgroundColor: element.type === 'button' ? 'blue' : 'transparent',
//         color: element.type === 'button' ? 'white' : 'inherit',
//         borderRadius: element.type === 'button' ? '5px' : '0',
//     };

//     const handleMouseEnter = () => {
//         setHovered(true);
//     };

//     const handleMouseLeave = () => {
//         setHovered(false);
//     };

//     return (
//         <div
//             ref={drag}
//             style={style}
//             onMouseEnter={handleMouseEnter}
//             onMouseLeave={handleMouseLeave}
//         >
//             {element.text}

//             {hovered && (
//                 <div className="absolute top-[-40px] flex space-x-2 bg-white text-white p-1 rounded shadow-md">
//                 <FaPen className="cursor-pointer text-black hover:text-yellow-500" title="Edit" />
//                 <div className="relative group">
//                     <button className="cursor-pointer text-black hover:text-yellow-500">
//                         Primarly
//                     </button>
//                     <ul className="absolute hidden group-hover:block bg-white text-black rounded shadow-lg">
//                         <li className="p-2 hover:bg-gray-200 cursor-pointer">Single Option</li>
//                     </ul>
//                 </div>
//                 <FaCopy className="cursor-pointer text-black hover:text-yellow-500" title="Copy" />
//                 <FaThumbtack className="cursor-pointer text-black hover:text-yellow-500" title="Pin" />
//                 <FaLink className="cursor-pointer text-black hover:text-yellow-500" title="Link" />
//                 <FaTrash className="cursor-pointer text-red-500 hover:text-red-700" title="Delete" />
//             </div>
            
//             )}
//         </div>
//     );
// };

// export default TextElement;

