import React, { useState } from 'react';
import { useDrag } from 'react-dnd';
import { GoPencil } from 'react-icons/go';
import { RiPaintFill } from 'react-icons/ri';
import { MdOutlineVerticalAlignCenter } from 'react-icons/md';
import { RiDeleteBin6Line } from 'react-icons/ri';
import { GiPin } from "react-icons/gi";
import { PiCopySimpleLight } from "react-icons/pi";

const ItemTypes = {
  TEXT_ELEMENT: 'TEXT_ELEMENT'
};

const TextElement = ({ element, moveTextElement }) => {
  const [hovered, setHovered] = useState(false);
  const [touched, setTouched] = useState(false); 

  const [{ isDragging }, drag, preview] = useDrag({
    type: ItemTypes.TEXT_ELEMENT,
    item: { id: element.id, left: element.left, top: element.top },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  });

  const handleMouseEnter = () => {
    setHovered(true);
  };

  const handleMouseLeave = () => {
    setHovered(false);
  };

  const handleDragEnd = (e) => {
    const { clientX, clientY } = e;
    moveTextElement(element.id, clientX, clientY);
  };

  const handleTouchStart = (e) => {
    setTouched(true); // Show toolkits on touch start
    const touch = e.touches[0];
    moveTextElement(element.id, touch.clientX, touch.clientY);
  };

  const handleTouchEnd = () => {
    setTouched(false); // Hide toolkits on touch end
  };

  const handleTouchMove = (e) => {
    const touch = e.touches[0];
    moveTextElement(element.id, touch.clientX, touch.clientY);
  };

  return (
    <div
      ref={drag}
      style={{
        position: 'absolute',
        left: element.left,
        top: element.top,
        transform: 'translate(-50%, -50%)',
        cursor: isDragging ? 'grabbing' : 'move',
        fontSize: element.fontSize || '16px',
        margin: '10px',
        border: (hovered || touched) ? '2px dashed white' : 'none',
        padding: element.type === 'button' ? '10px 20px' : '0',
        backgroundColor: element.type === 'button' ? 'blue' : 'transparent',
        color: element.type === 'button' ? 'white' : 'inherit',
        borderRadius: element.type === 'button' ? '5px' : '0',
        zIndex: (hovered || touched) ? 10 : 1,
        opacity: isDragging ? 0.5 : 1,
      }}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      onDragEnd={handleDragEnd}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      draggable
    >
      {element.text}

      {(hovered || touched) && (
        <div className="absolute top-[-42px] flex space-x-2 bg-white text-black p-2 rounded shadow-md">
          <GoPencil
            className="cursor-pointer hover:text-yellow-500"
            title="Edit"
            style={{ width: '20px', height: '20px', marginRight: '10px' }}
          />
          <RiPaintFill
            className="cursor-pointer hover:text-yellow-500"
            title="Paint"
            style={{ width: '20px', height: '20px', marginRight: '10px' }}
          />
          <MdOutlineVerticalAlignCenter
            className="cursor-pointer hover:text-yellow-500"
            title="Pin"
            style={{ width: '20px', height: '20px', marginRight: '10px' }}
          />
          <GiPin
            className="cursor-pointer hover:text-yellow-500"
            title="Pin"
            style={{ width: '20px', height: '20px', marginRight: '10px' }}
          />
          <PiCopySimpleLight
            className="cursor-pointer hover:text-yellow-500"
            title="Copy"
            style={{ width: '20px', height: '20px', marginRight: '10px' }}
          />
          <RiDeleteBin6Line
            className="cursor-pointer text-red-500 hover:text-red-700"
            title="Delete"
            style={{ width: '20px', height: '20px', marginRight: '10px' }}
          />
        </div>
      )}
    </div>
  );
};

export default TextElement;
