import React, { useEffect, useState } from 'react';
import { CiMobile1 } from 'react-icons/ci';
import { FaDesktop } from 'react-icons/fa';
import BackgroundImage from "../Assets/images.jpg";
import TextElement from './DragItem';
import { DndProvider, useDrop } from 'react-dnd';
import { FaBars, FaTimes } from 'react-icons/fa';
import { PiPaintBrushHouseholdBold } from 'react-icons/pi';
import { GoArrowUpRight } from 'react-icons/go';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { TbArrowForwardUp, TbArrowBackUp } from "react-icons/tb";
import { useNavigate } from 'react-router-dom';

const ItemTypes = {
  TEXT_ELEMENT: 'TEXT_ELEMENT'
};

const EditPage = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isMobileView, setIsMobileView] = useState(false);
  const navigate = useNavigate();

  const [mobileTextElements, setMobileTextElements] = useState([
    { id: 1, text: 'Introduce your brand', left: '50%', top: '30%', fontSize: '3vw' },
    { id: 2, text: 'Welcome People to your site with an intro that is short, sweet like you', left: '50%', top: '50%', fontSize: '2.5vw' },
    { id: 3, text: 'Learn More ', left: '50%', top: '70%', type: 'button', fontSize: '1.5vw' },
  ]);

  const [desktopTextElements, setDesktopTextElements] = useState([
    { id: 1, text: 'Introduce your brand', left: '50%', top: '30%', fontSize: '3vw' },
    { id: 2, text: 'Welcome People to your site with an intro that is short, sweet like you', left: '50%', top: '50%', fontSize: '2.5vw' },
    { id: 3, text: 'Learn More', left: '50%', top: '70%', type: 'button', fontSize: '1.5vw' },
  ]);

  const [buttonsActive, setButtonsActive] = useState(false);

  // Toggle between mobile and desktop views
  const toggleView = (view) => {
    setIsMobileView(view === 'mobile');
  };

  // Update device type on resize
  useEffect(() => {
    const handleResize = () => {
      // Optionally adjust view based on window size
      if (window.innerWidth < 768) {
        setIsMobileView(true);
      } else {
        setIsMobileView(false);
      }
    };
    window.addEventListener('resize', handleResize);
    handleResize(); // Check initial size
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const moveTextElement = (id, left, top) => {
    if (isMobileView) {
      setMobileTextElements(prevElements =>
        prevElements.map(element =>
          element.id === id ? { ...element, left, top } : element
        )
      );
    } else {
      setDesktopTextElements(prevElements =>
        prevElements.map(element =>
          element.id === id ? { ...element, left, top } : element
        )
      );
    }
    setButtonsActive(true);
  };

  const saveChanges = () => {
    console.log('Saved elements:', isMobileView ? mobileTextElements : desktopTextElements);
    localStorage.setItem('textElements', JSON.stringify(isMobileView ? mobileTextElements : desktopTextElements));
    setButtonsActive(false);
  };

  const exitAndReset = () => {
    if (isMobileView) {
      setMobileTextElements([
        { id: 1, text: 'Introduce your brand', left: '50%', top: '30%', fontSize: '3vw' },
        { id: 2, text: 'Welcome People to your site with an intro that is short, sweet like you', left: '50%', top: '50%', fontSize: '2.5vw' },
        { id: 3, text: 'Learn More', left: '50%', top: '70%', type: 'button', fontSize: '1.5vw' },
      ]);
    } else {
      setDesktopTextElements([
        { id: 1, text: 'Introduce your brand', left: '50%', top: '30%', fontSize: '3vw' },
        { id: 2, text: 'Welcome People to your site with an intro that is short, sweet like you', left: '50%', top: '50%', fontSize: '2.5vw' },
        { id: 3, text: 'Learn More', left: '50%', top: '70%', type: 'button', fontSize: '1.5vw' },
      ]);
    }
    setButtonsActive(false);
  };

  const [, drop] = useDrop({
    accept: ItemTypes.TEXT_ELEMENT,
    drop: (item, monitor) => {
    }
  });

  const toggleMenu = () => setIsOpen(!isOpen);

  return (
    <DndProvider backend={HTML5Backend}>
      <div className={`relative w-full h-screen overflow-hidden ${isMobileView ? 'bg-gray-100 p-4' : ''}`}>
        <img
          src={BackgroundImage}
          alt="Background"
          className={`absolute inset-0 w-full h-full object-cover ${isMobileView ? 'opacity-50' : ''}`}
        />

        <nav className="absolute top-0 left-0 w-full flex items-center justify-between p-4 bg-opacity-50 bg-black text-white z-20">
          <div className="flex items-center space-x-2">
            <button
              className={`text-lg font-semibold py-2 px-4 rounded border-2 focus:outline-none focus:ring-2 ${buttonsActive ? 'bg-black border-black text-white hover:bg-black hover:text-white' : 'bg-transparent border-gray-400 text-gray-600 hover:bg-black hover:text-white'}`}
              onClick={buttonsActive ? saveChanges : undefined}
              disabled={!buttonsActive}
            >
              Save
            </button>
            <button
              className={`text-lg font-semibold py-2 px-4 rounded border-2 focus:outline-none focus:ring-2 ${buttonsActive ? 'bg-black border-black text-white hover:bg-black hover:text-white' : 'bg-transparent border-gray-400 text-gray-600 hover:bg-black hover:text-white'}`}
              onClick={exitAndReset}
            >
              Exit
            </button>
            <button
              className="w-8 h-8 cursor-pointer hover:text-gray-700"
              onClick={() => navigate('/')}
              title="Back"
            >
              <TbArrowBackUp className="w-8 h-8" />
            </button>
            <button
              className="w-8 h-8 cursor-pointer hover:text-gray-700"
              onClick={() => navigate('/edit')}
              title="Forward"
            >
              <TbArrowForwardUp className="w-8 h-8" />
            </button>
          </div>


          <div className="lg:hidden flex items-center" onClick={toggleMenu}>
            {isOpen ? <FaTimes className="text-white" /> : <FaBars className="text-white" />}
          </div>

          
          <div
            className={`lg:flex items-center space-x-4 ml-auto ${isOpen ? 'block' : 'hidden'
              } lg:block`}
          >
            <CiMobile1
              className={`text-2xl cursor-pointer ${isMobileView ? 'text-white' : 'text-white'}`}
              title="Mobile"
              onClick={() => toggleView('mobile')}
            />
            <FaDesktop
              className={`text-2xl cursor-pointer ${!isMobileView ? 'text-white' : 'text-white'}`}
              title="Desktop"
              onClick={() => toggleView('desktop')}
            />
            <PiPaintBrushHouseholdBold
              className="text-2xl cursor-pointer text-white"
              title="Paint"
              onClick={() => toggleView('paint')}
            />
            <GoArrowUpRight
              className="text-2xl cursor-pointer text-white"
              title="Go Up"
              onClick={() => toggleView('goUp')}
            />
          </div>
        </nav>

        <div ref={drop} className={`absolute inset-0 flex flex-col items-center justify-center text-center text-white z-10 ${isMobileView ? 'p-4' : ''}`}>
          {(isMobileView ? mobileTextElements : desktopTextElements).map((element) => (
            <TextElement
              key={element.id}
              element={element}
              moveTextElement={moveTextElement}
              style={{
                fontSize: element.fontSize,
                position: 'absolute',
                left: element.left,
                top: element.top,
              }}
            />
          ))}
        </div>
      </div>
    </DndProvider>
  );
};

export default EditPage;
