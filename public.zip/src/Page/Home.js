import React, { useState } from 'react';
import { FaBars, FaTimes } from 'react-icons/fa';
import { Link } from 'react-router-dom'; 
import BackgroundImage from "../Assets/images.jpg";
import TextElement from './DragItem';
import { useDrop } from 'react-dnd';

const Home = () => {
    const [isOpen, setIsOpen] = useState(false);
    const [textElements, setTextElements] = useState([
        { id: 1, text: 'Introduce your brand', left: '50%', top: '30%', fontSize: '3vw' },
        { id: 2, text: 'Welcome People to your site with an intro that is short, sweet like you', left: '50%', top: '50%', fontSize: '2.5vw' },
        { id: 3, text: 'Learn More', left: '50%', top: '70%', type: 'button', fontSize: '1.5vw' },
      ]);


    
    const moveTextElement = (id, left, top) => {
        setTextElements((prevElements) =>
            prevElements.map((element) =>
                element.id === id ? { ...element, left, top } : element
            )
        );
    };

    const [ , drop] = useDrop({
        accept: 'TEXT_ELEMENT',
        drop: (item, monitor) => {
            // const offset = monitor.getClientOffset();
            // const rect = document.getElementById('canvas').getBoundingClientRect();
            // const x = offset.x - rect.left;
            // const y = offset.y - rect.top;
            // moveTextElement(item.id, `${x}px`, `${y}px`);
        },
    });
    const toggleMenu = () => {
        setIsOpen(!isOpen);
    };

    return (
        <div className="relative w-full h-screen">
            <img
                src={BackgroundImage}
                alt="Background"
                className="absolute inset-0 w-full h-full object-cover"
            />

            <nav className="absolute top-0 left-0 w-full flex items-center justify-between p-4 bg-opacity-5 text-white z-20">
            
                <div className="flex items-center">
                    <Link to="/edit" className="text-lg font-semibold py-2 px-4 rounded border-2 focus:outline-none focus:ring-2">
                        Edit
                    </Link>
                </div>

                <div className="lg:hidden" onClick={toggleMenu}>
                    {isOpen ? <FaTimes /> : <FaBars />}
                </div>

            </nav>

            <div className="absolute inset-0 flex flex-col items-center justify-center text-center text-white z-10">
                {textElements.map((element) => (
                    <TextElement
                        key={element.id}
                        element={element}
                        className="font-bold"
                        moveTextElement={moveTextElement}
                    />
                ))}
            </div>
        </div>
    );
};

export default Home;
